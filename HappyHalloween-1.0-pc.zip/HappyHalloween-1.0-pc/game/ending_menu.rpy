# =====================================================
#  메인 메뉴 + 엔딩 모음
#  game/ending_menu.rpy 로 저장하세요
#  ※ screens.rpy 안의 원래 'screen main_menu():' 블록은 삭제해야 합니다
# =====================================================

# 엔딩 해금 기록 (게임을 껐다 켜도 유지됨)
default persistent.endings = set()

# 엔딩 목록 버튼의 글자색 (이 두 줄만 바꾸면 됩니다)
define ending_text_idle_color = "#707070"       # 평소
define ending_text_selected_color = "#ff94a4"   # 선택됐을 때

init python:
    # (엔딩 id, 표시 이름, 재생할 라벨)
    ENDING_LIST = [
        ("true",    "괴담?",     "ending_true_mummy"),
        ("gate",    "교문 앞의 약속",             "ending_gate_promise"),
        ("cthulhu", "진짜 공포",              "ending_cthulhu"),
        ("clear",   "7대불가사의 완전 해결",      "ending_all_clear"),
    ]

# -----------------------------------------------------
#  메인 메뉴
# -----------------------------------------------------
screen main_menu():
    tag menu

    add gui.main_menu_background

    # 로고나 타이틀 이미지를 넣고 싶다면 아래 주석을 풀고 경로를 맞추세요
    # add "images/ui/ui_title_logo.png" xalign 0.5 ypos 120

    vbox:
        xalign 0.88
        yalign 0.87
        spacing 24

        textbutton "시작하기" action Start() xalign 0.5 text_size 53
        textbutton "엔딩 모음" action ShowMenu("ending_gallery") xalign 0.5 text_size 53
        textbutton "종료" action Quit(confirm=False) xalign 0.5 text_size 53 text_hover_color "ffffff"

# -----------------------------------------------------
#  엔딩 모음 화면
# -----------------------------------------------------
screen ending_gallery():
    tag menu
    default sel = None                    # 지금 고른 엔딩 id

    add gui.game_menu_background

    text "엔딩 모음" size 70 xalign 0.5 ypos 50
    text "달성: [len(persistent.endings)] / [len(ENDING_LIST)]" size 36 xalign 0.5 ypos 150

    hbox:
        xalign 0.5
        ypos 240
        spacing 80

        # ---- 왼쪽: 엔딩 목록 ----
        vbox:
            spacing 20
            for eid, ename, elabel in ENDING_LIST:
                # fit_first: 첫 번째 자식(버튼 이미지) 크기에 맞춤 → 이미지 원본 크기 유지
                fixed:
                    fit_first True

                    if eid in persistent.endings:
                        imagebutton:
                            idle "images/ui/ui_ending_menu_idle.png"
                            action SetScreenVariable("sel", eid)
                            selected (sel == eid)
                        text "[ename]" size 40 align (0.5, 0.5) color (ending_text_selected_color if sel == eid else ending_text_idle_color)
                    else:
                        add "images/ui/ui_ending_menu_idle.png"
                        text "? ? ?" size 40 color "#888888" align (0.5, 0.5)

        # ---- 오른쪽: 선택한 엔딩 미리보기 ----
        vbox:
            spacing 20
            if sel is not None:
                add Transform("cg end_%s_01" % sel, fit="contain", xysize=(800, 450))
                $ target = [e[2] for e in ENDING_LIST if e[0] == sel][0]
                textbutton "다시 보기" action Replay(target)


    textbutton "돌아가기":
        action Return()
        xalign 0.5
        yalign 0.97
