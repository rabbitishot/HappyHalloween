# =====================================================
#  학교의 7대불가사의 - script.rpy (1920x1080 기준)
#  - 이미지 파일이 없으면 자동으로 임시 이미지(색 사각형/글자)가 뜹니다
#  - 파일을 넣으면 같은 이름 규칙의 실제 이미지로 자동 교체됩니다
#  - 엔딩 해금은 ending_menu.rpy 의 persistent.endings 와 연결됩니다
# =====================================================

define hero = Character("감라빛", color="#ffb6c1")
define me = Character("나", color="#5E84B5FF")



# ---------- 게임 상태 변수 (세이브/롤백 대상) ----------
default minutes_used = 0        # 23:00 부터 흐른 시간(분)
default current_loc = "gate"    # 현재 위치
default solved = []             # 해결한 불가사의 id 목록
default checked = []            # 이미 조사한 물건 id 목록
default gate_returns = 0        # 교문으로 돌아온 횟수
default visited = []            # 이미 가본 장소
default warn_stage = 0          # 지금까지 알린 가장 높은 경고 단계


# ---------- 히로인 위치 ----------
define hero_x = 1.0            # 히로인 기본 가로 위치 (여기만 바꾸면 전부 반영)
define hero_y = 0.95
define hero_zoom = 0.9

transform hero_pos:
    xalign hero_x
    yalign hero_y
    yoffset 0                       # 이전 transform의 오프셋을 지움

# 오른쪽 화면 밖에서 위아래로 통통 흔들리며 기본 자리까지 등장
transform hero_enter:
    xpos 1.0 xanchor 0.0 yalign hero_y     # 화면 오른쪽 바깥에서 시작
    parallel:
        ease 1.2 xalign hero_x          # 기본 자리까지 이동
    parallel:
        block:
            ease 0.15 yoffset -18       # 위로
            ease 0.15 yoffset 0         # 아래로 (0으로 끝나야 튀지 않음)
        repeat 4                        # 4번 반복 (0.3초 x 4 = 1.2초)
    yoffset 0

# ---------- cg 위치 ----------
define cg_x = 0.5            # 히로인 기본 가로 위치 (여기만 바꾸면 전부 반영)
define cg_y = 0.5
define cg_zoom = 1.1

transform cg_pos:
    xalign cg_x
    yalign cg_y
    yoffset 0   

# cg 흔들림
transform cg_shake:
    # 시작 위치 (화면 중앙 기준, ypos로 조절 가능)
    yalign cg_x
    xalign cg_y
    # 2초 동안 위로 20픽셀 이동 후, 다시 2초 동안 아래로 20픽셀 이동 (무한 반복)
    linear 0.3 yalign 0.48 xalign 0.48
    linear 0.3 yalign 0.5 xalign 0.5
    repeat

transform slow_zoom:
    xalign 0.5 yalign 0.5
    zoom 1.0
    linear 2.0 zoom 0.5        # 6초 동안 1.25배까지 확대
# =====================================================
#  고정 데이터
# =====================================================
init python:
    TOTAL_MINUTES = 420         # 23:00 ~ 06:00 = 7시간

    # (id, 이름) - 지도에 표시되는 순서. id 는 배경 파일명과 같게!
    LOCS = [
        ("gate",   "교문"),
        ("class",  "2학년 교실"),
        ("music",  "음악실"),
        ("pool",   "수영장"),
        ("toilet", "여자화장실"),
        ("stairs", "중앙계단"),
        ("library","도서관"),
        ("nurse",  "보건실"),
        ("backyard", "뒤뜰"),
    ]
    LOC_NAME = dict(LOCS)

    ITEM_COST = 8               # 물건 하나 조사
    RUMOR_COST = 8              # 처음 방문 소문 이야기
    SOLVE_COST = 5              # 불가사의 해결 대화
    TRUE_END_MIN = 300          # 보건실 진엔딩 가능 시각 (04:00)

    # 복도 연결 (분). 직접 이어진 곳만 적으면 나머지는 자동 계산
    EDGES = [
        ("gate", "stairs", 15),   ("gate", "backyard", 20),
        ("stairs", "class", 15),  ("stairs", "music", 20),
        ("stairs", "toilet", 10), ("stairs", "library", 15),
        ("stairs", "nurse", 10),  ("stairs", "pool", 25),
        ("class", "toilet", 10),  ("nurse", "library", 10),
        ("library", "backyard", 20), ("backyard", "pool", 15),
    ]

    def build_travel():
        ids = [k for k, _ in LOCS]
        INF = 10 ** 6
        d = {a: {b: (0 if a == b else INF) for b in ids} for a in ids}
        for a, b, w in EDGES:
            d[a][b] = min(d[a][b], w)
            d[b][a] = min(d[b][a], w)
        for k in ids:
            for i in ids:
                for j in ids:
                    if d[i][k] + d[k][j] < d[i][j]:
                        d[i][j] = d[i][k] + d[k][j]
        return d

    TRAVEL_MAP = build_travel()

    def travel_cost(a, b):
        return TRAVEL_MAP[a][b]

    # (시작 분, 단계, 대사) - 큰 시간부터 적기
    WARN_STAGES = [
        (400, 3, "이제 진짜 시간이 없다 잉잉 그래서"),
        (300, 2, "아으 슬슬 조금 서둘러야 할지도...쨋든~"),
        (180, 1, "헉 시간이 꽤 지났네! 암튼!"),
    ]

    def check_warning():
        global warn_stage
        for t, stage, text in WARN_STAGES:
            if minutes_used >= t:
                if stage > warn_stage:
                    warn_stage = stage
                    return text
                return None
        return None

    # 7대불가사의 (id: 이름)  ※ 장소마다 하나씩, 총 7개
    MYSTERIES = {
        "desk":   "주인없는 책상",        # 교실
        "piano":  "혼자 연주되는 피아노",        # 음악실
        "swim":  "먼저 도착하는 상대",        # 수영장
        "window":  "화장실의 울음소리",             # 화장실
        "stair":  "13번째 계단",                 # 중앙계단
        "book":   "도서관의 수상한 책",               # 도서관
        "bed": "죽은 여학생의 원한",   # 보건실
        "bunny": "뒤뜰의 침입자",   # 뒤뜰
    }

    # 장소별 조사 물건: (item_id, 이름, 조사 텍스트, 불가사의 id 또는 None)
    ITEMS = {

        "class": [
            ("c1", "사물함", "누군가의 체육복이 들어 있다. 그런데 도대체 언제 빤거지?\n엄청난 악취다.", None),
            ("c2", "출석부", "평범한 출석부. 자리배치도가 같이 끼워져있었다.", "desk"),
            ("c3", "맨 뒷자리 책상", "누군가 이름을 새겨뒀다. 정말 나쁘군", "desk"),
            ("c4", "바닥", "나무라서 그런지 군데군데 패여있다. \n리모델링이 필요할 것 같다.", None),
            ("c5", "쓰레기통", "최근에 쪽지시험이 있었나보다.\n 어려운 구간이라 그런지 점수들이 처참하다", None),
        ],
        "music": [
            ("m1", "메트로놈", "대실일지를 찾아보니 밴드부의 서명이 있었다.\n잘 끄고다녀 이짜식들!", None),
            ("m2", "그랜드 피아노", "망가진 피아노였다.\n그럼 음악수업은 어떻게 한거지?", "piano"),
            ("m3", "악보 더미", "중요한건 없었다.", None),
            ("m4", "피아노 의자", "블루투스 스피커가 들어있다.\n누군가의 분실물일까?", "piano"),
        ],
        "pool": [
            ("p1", "수영장 사다리", "뭔가 삐걱거린다. 고쳐라 좀!", None),
            ("p2", "펜스", "구석자리에 옷가지나 수건이 널려있다.\n여기서 말려도 괜찮은걸까?", "swim"),
            ("p3", "수영장 레인", "평범한 레일이다. 잘 보일 수 있게 쨍한 색이다", None),
            ("p4", "여자 탈의실", "안쪽에는 별거 없다고 한다. 흠. 보여주지 않으면 안믿음", None),
        ],
        "toilet": [
            ("t1", "거울", "별건 없었다. 거울속의 나는 피곤해도 꽤나 멋있군", None),
            ("t2", "4번째 칸 문", "별건 아니지만 창문이 이렇게 커도 돼?", "window"),
            ("t3", "세면대", "상태가 좋아! 음음 집 볼 때 정말 중요한 부분이다", None),
            ("t4", "청소도구함", "평범하게 물건들이 잘 정리되어 있었다.\n의외로 관리가 잘되는 듯 하다", None),
        ],
        "stairs": [
            ("s1", "소화기", "유효기한이 지났다. 선생님께 이야기해두는게 좋을 것 같다.", None),
            ("s2", "계단 층계참", "세어 보니 선배랑 개수가 달랐다. 그럼 소문이 진짜?", "stair"),
            ("s3", "비상구 표지판", "초록색으로 반짝인다. 선배와 사랑의 도피를 떠나고싶다.", None),
            ("s4", "거울", "별건 없지만 거울에 비친 선배가 귀엽네", None),
        ],
        "library": [
            ("l1", "대출 카운터", "평범하게 컴퓨터가 놓여있다. 정말 평범한 상태다.", None),
            ("l2", "신문 열람대", "작년 신문이 쌓여 있다. 굳이 관리할 이유가 없겠지.", None),
            ("l3", "도서분류표", "평소엔 읽어볼 생각은 안했던 것 같다", "book"),
            ("l4", "책장", "책이 생각한 것 보다도 훨씬 많다.", "book"),
        ],
        "nurse": [
            ("n1", "체온계", "36.5도, 정상이다. 체온계도 멀쩡하다.", None),
            ("n2", "침대", "평범한 침대였다. 그럼 소문은 어디서 시작한거지?", "bed"),
            ("n3", "약장", "확인할 순 없지만 소문의 원인은 아닌 것 같다.", "bed"),
            ("n4", "체중계", "아마도 망가져있다. 이것 때문에 일어난 일은 아닌 것 같다.", "bed"),
        ],
        "backyard": [
            ("b1", "낡은 벤치", "페인트가 벗겨진 벤치다. 밤이슬에 젖어 있다.", None),
            ("b2", "구덩이", "가장 수상했던 땅굴은 선배가 만든거였다.", "bunny"),
            ("b3", "화단", "식물들이 마구 망가져있다. 선배의 짓이였다.", "bunny"),
        ],
    }

    # 선행 조사가 필요한 물건: {물건 id: 먼저 조사해야 할 물건 id}
    REQUIRES = {
        "l4": "l3",
    }

    # 순서가 틀렸을 때 나오는 문장
    LOCKED_TEXT = {
        "l4": "책장에는 수많은 책이 빽빽하게 꽂혀 있다. 어디서부터 찾아야 할지 감이 안 온다...",
    }

    ITEM_BY_ID = {}
    for _loc, _lst in ITEMS.items():
        for _it in _lst:
            ITEM_BY_ID[_it[0]] = _it

    NEED_SOLVE = 7                       # 이만큼 해결하면 클리어

    REPEATABLE = {"l4"}                  # 조사한 뒤에도 다시 누를 수 있는 물건

    REQUIRES = {"l4": "l3"}              # l4 는 l3 를 먼저 조사해야 함
    LOCKED_TEXT = {
        "l4": "책장에는 수많은 책이 빽빽하게 꽂혀 있다. 어디서부터 찾아야 할지 감이 안 온다...",
    }

    def clue_total(mid):
        return sum(1 for it in ITEM_BY_ID.values() if it[3] == mid)

    def clue_found(mid):
        return sum(1 for iid in checked if ITEM_BY_ID[iid][3] == mid)

    # ----- 시간 관련 함수 -----
    def clock_text():
        total = 23 * 60 + minutes_used
        return "%02d:%02d" % ((total // 60) % 24, total % 60)

    def remaining():
        return TOTAL_MINUTES - minutes_used

    def loc_mystery(loc):
        # 그 장소의 불가사의 (id, 이름). 없으면 (None, None)
        for it in ITEMS.get(loc, []):
            if it[3] is not None:
                return it[3], MYSTERIES.get(it[3], "???")
        return None, None

    def clue_total(mid):
        # 이 불가사의의 단서 물건 개수
        return sum(1 for it in ITEM_BY_ID.values() if it[3] == mid)

    def clue_found(mid):
        # 지금까지 조사한 단서 개수
        return sum(1 for iid in checked if ITEM_BY_ID[iid][3] == mid)

    # ----- 이미지: 파일이 있으면 사용, 없으면 임시 이미지 -----
    def placeholder(label, color="#334455"):
        return Fixed(
            Solid(color),
            Text(label, size=80, color="#ffffff", xalign=0.5, yalign=0.5),
        )

    # 배경: images/bg/bg_장소ID.png
    for _key, _name in LOCS:
        _path = "images/bg/bg_%s.png" % _key
        if renpy.loadable(_path):
            renpy.image("bg " + _key, _path)
        else:
            renpy.image("bg " + _key, placeholder(_name))

    # 엔딩 CG: images/cg/cg_end_이름_01.png ~ 03.png
    # 게임 안에서는 cg end_true_01, cg end_true_02 ... 처럼 번호까지 붙여서 부릅니다
    for _key, _name, _color in [
        ("true",    "TRUE END",    "#553344"),
        ("gate",    "NORMAL END",  "#446655"),
        ("cthulhu", "SECRET END",  "#223355"),
        ("clear",   "CLEAR END",   "#665544"),
    ]:
        for _n in range(1, 4):
            _path = "images/cg/cg_end_%s_%02d.png" % (_key, _n)
            _img = "cg end_%s_%02d" % (_key, _n)
            if renpy.loadable(_path):
                renpy.image(_img, _path)
            else:
                renpy.image(_img, placeholder("%s (CG %02d)" % (_name, _n), _color))

    # 히로인 표정: images/hero/hero_표정.png (표정마다 통짜 이미지 1장)
    HERO_FACES = [
        "normal", "smile", "veryhappy", "surprise", "upset",
        "sad", "angry", "shy", "talk", "think", "proud", "sneer", "happy", "surprise_c", "think_c"
    ]

    for _f in HERO_FACES:
        _path = "images/hero/hero_%s.png" % _f
        if renpy.loadable(_path):
            renpy.image("hero " + _f, _path)
        else:
            # 파일이 없으면 임시 이미지
            renpy.image("hero " + _f, Fixed(
                Solid("#cc8899", xysize=(500, 1000)),
                Text(_f, size=60, color="#ffffff", xpos=140, ypos=120),
            ))

# 상단 공통 HUD: 시각, 해결 수
screen hud():
    frame:
        align (1.0, 0.0)
        padding (24, 16)
        vbox:
            text "[clock_text()]" size 60
            text "불가사의 [len(solved)] / [NEED_SOLVE]" size 30

# 이동 지도
screen map_screen():
    use hud
    frame:
        align (0.1, 0.5)
        padding (45, 45)
        vbox:
            spacing 12
            text "어디로 갈까? (현재: [LOC_NAME[current_loc]])" size 42
            for key, name in LOCS:
                textbutton "[name]":
                    text_size 36
                    action Return(key)
                    sensitive (key != current_loc)
            if current_loc != "gate":
                textbutton "돌아가기 ([LOC_NAME[current_loc]])":
                    text_size 36
                    action Return("stay")   
            null height 15
            textbutton "집" text_size 36 action Return("end")

# 장소 조사 화면
screen explore_screen():
    use hud
    frame:
        align (0.1, 0.5)
        padding (45, 45)
        vbox:
            spacing 12
            text "[LOC_NAME[current_loc]] - 조사할 곳을 클릭" size 42
            for it in ITEMS[current_loc]:
                if it[0] in checked and it[0] not in REPEATABLE:
                    textbutton "[it[1]] (확인함)" text_size 36 action NullAction() sensitive False
                else:
                    textbutton "[it[1]]" text_size 36 action Return(it[0])
            null height 15
            textbutton "다른 곳으로 이동한다" text_size 36 action Return("back")


# =====================================================
#  게임 본편
# =====================================================

label start:
    scene bg gate

    "밤 11시. 아무도 없는 학교 교문 앞."


    # 발소리 시작: 대사와 동시에 무음에서 점점 커짐
    play sound "audio/sfx/sfx_footstep.mp3" loop fadein 5.5

    "{size=-14}거...{/size}{w=0.8}{size=-9}부...{/size}{w=0.8}{size=-4}이...{/size}{w=0.7}{size=+6}거부이야~!!!!!!!{/size}{w=1.0}{nw}"

    stop sound fadeout 1.4
    show hero smile at hero_enter
    hero "와줬구나! 후후 역시 선배랑 학교의 7대불가사의를 밝혀내고싶은거지~?"

    menu:
        hero "선배랑 한밤의 학교는 어떤 기분이야?"

        "거뿌이 너무 무서워...앙앙":
            show hero proud
            hero "선배가 지켜줄게! 걱정마"

        "선배가 안오면 끓여버린다고 했잖아요":
            show hero angry
            hero "그거슨 별로 중요하지않은 것 같아"

    me "해 뜨기 전에는 집에 가야할 것 같아요"

    show hero think
    hero "아무래도아무래도 그렇겠지? 6시전에는 돌아가자"

label main_loop:
    if remaining() <= 0:
        jump ending_check

    show hero normal at hero_pos
    call screen map_screen
    $ dest = _return
    # 돌아가기: 이동하지 않고 지금 있는 장소의 조사 화면으로
    if dest == "stay":
        jump explore_loop
    if dest == "end":
        show hero think
        menu:
            hero "정말로 여기서 끝이야?"

            "응, 그만할래":
                show hero sad
                hero "...잉 알아쏘 오늘은 그만하자..."
                jump ending_check

            "아니야! 더 하자":
                show hero veryhappy
                hero "쪼아! 그럼 계속 가보자!"
                jump main_loop

    $ cost = travel_cost(current_loc, dest)
    $ minutes_used += cost
    $ current_loc = dest

    scene expression ("bg " + current_loc)
    show hero normal at hero_pos
    with fade

    "[LOC_NAME[current_loc]](으)로 이동했다..."

    if remaining() <= 0:
        jump ending_check

    # 시간 경고 (교문에서도 나오도록 먼저 확인)
    $ warn_line = check_warning()
    if warn_line:
        show hero upset
        hero "[warn_line]"
        show hero normal

    # 교문은 조사 없이 이벤트만 보고 바로 지도로
    if current_loc == "gate":
        call event_gate_return from _call_event_gate_return
        jump main_loop

    # 처음 가면 소문 이야기, 다시 가면 괴담 이름만 한 번 더
    if current_loc not in visited:
        $ visited.append(current_loc)
        if renpy.has_label("rumor_" + current_loc):
            call expression ("rumor_" + current_loc) from _call_expression
            $ minutes_used += RUMOR_COST
    else:
        $ rid, rname = loc_mystery(current_loc)
        if rid is not None:
            show hero think
            if rid in solved:
                hero "여기는 분명 「[rname]」 괴담이었지? 벌써 해결했지만!"
            else:
                hero "여기는 분명 「[rname]」 괴담이었지?"
            show hero normal

label explore_loop:
    call screen explore_screen
    $ pick = _return

    if pick == "back":
        jump main_loop

    $ item = ITEM_BY_ID[pick]

    # ① 이미 조사한 물건을 다시 누름 (시간 소모 없음)
    if pick in checked:
        "[item[1]]을(를) 꼼꼼히 살펴봤다."
        "[item[2]]"
        jump explore_loop

    # ② 보건실 침대: 0개 해결 + 04:00 이후에만 특별 선택지
    if pick == "n2" and len(solved) == 0 and minutes_used >= TRUE_END_MIN:
        show hero normal
        "침대 시트가 포근해보인다 지친걸까"

        menu:
            "침대에 몸을 눕힌다":
                jump ending_true_mummy

            "꼼꼼히 조사해본다":
                show hero normal
                hero "음 특별한건 없어보이는데.. 그렇지?"

    # ③ 선행 조사가 필요한 물건 (아직 못 본 걸로 처리, checked 에 안 넣음)
    if pick in REQUIRES and REQUIRES[pick] not in checked:
        $ minutes_used += ITEM_COST
        "[item[1]]을(를) 살펴봤다. ([ITEM_COST]분 소요)"
        "[LOCKED_TEXT[pick]]"
        show hero think
        hero "음... 뭔가 먼저 확인해야 할 게 있을 것 같은데?"
        show hero normal
        if remaining() <= 0:
            jump ending_check
        jump explore_loop

    # ④ 정상 조사: 시간 소모, 기록
    $ minutes_used += ITEM_COST
    $ checked.append(pick)

    # ⑤ 이 물건 전용 대화 (조사 텍스트보다 먼저)
    if renpy.has_label("item_" + pick):
        call expression ("item_" + pick) from _call_expression_1

    "[item[1]]을(를) 조사했다. ([ITEM_COST]분 소요)"
    "[item[2]]"

    # ⑥ 불가사의 단서 처리
    if item[3] is not None and item[3] not in solved:
        $ mid = item[3]
        $ found = clue_found(mid)
        $ total = clue_total(mid)

        if found >= total:

            # 히든 루트: 책이 마지막(7번째) 해결일 때
            if mid == "book" and len(solved) + 1 >= NEED_SOLVE:
                $ solved.append(mid)
                jump ending_cthulhu

            # 단서가 다 모였을 때의 멘트
            if renpy.has_label("clues_" + mid):
                call expression ("clues_" + mid) from _call_expression_2
            else:
                show hero think
                hero "잠깐... 지금까지 찾은 단서를 합쳐 보면..."

            # 해결 선언
            $ solved.append(mid)
            $ mname = MYSTERIES[mid]
            $ minutes_used += SOLVE_COST
            show hero smile
            hero "찾았다! 불가사의 해결 - 「[mname]」!"
            show hero veryhappy
            "(해결: [len(solved)] / [NEED_SOLVE])"
            show hero normal

        else:
            show hero think
            hero "아직은 단서가 조금 부족해 ([found]/[total])"
            show hero normal

    # ⑦ 엔딩 체크
    if len(solved) >= NEED_SOLVE:
        jump ending_all_clear

    if remaining() <= 0:
        jump ending_check

    jump explore_loop


# =====================================================
#  엔딩 분기
# =====================================================
label ending_check:
    if len(solved) >= len(MYSTERIES) and current_loc == "library":
        jump ending_cthulhu

    hide hero
    scene black with fade
    if remaining() <= 0:
        "...어느새 하늘이 밝아오기 시작했다."

    if len(solved) >= len(MYSTERIES):
        jump ending_all_clear
    elif len(solved) == 0 and current_loc == "nurse" and minutes_used >= TRUE_END_MIN:
        jump ending_true_mummy
    else:
        jump ending_gate_promise


label ending_true_mummy:
    $ persistent.endings.add("true")

    # 보건실 배경 + 히로인으로 시작
    scene bg nurse
    show hero normal at hero_pos

    "결국 아무것도 밝혀내지 못한 채, 지친 우리는 보건실에서 잠시 쉬기로 했다."

    show hero upset
    hero "우.. 결국 하나도 해결하지 못했어 후배야아~~"

    menu:
        "바보선배":
            show hero angry
            hero "잇쉬 바보후배주제에"

        "선배왕바보":
            show hero angry
            hero "후배는 대왕왕바보야 흥"
    hide hero
    scene black with Dissolve(0.2)
    pause 1.0
    "커튼을 훽 치며 나가버렸다"
    
    me "엄"
    "....."
    "........"
    "우우우~ 우~ 나는 짱 나쁜 유령이다"
        
    menu:
        "선배 너무 티나요":
            hero "나~ 선배아니다~ 우우우~"

        "헉; 앙앙 거부이 넘 무셔":
            hero "우하하 공포를 맞이해라"
    me "선배 이제 나와요"
    scene cg end_true_01 with Dissolve(2)
    hero "우... 크와와와왕 멋진 티라노공ㄹ"
    scene black with Dissolve(0.3)
    hero "에?"
    scene cg end_true_02 at cg_shake
    hero "에에엑?"
    scene black with Dissolve(0.2)
    hero "후배야..."
    scene cg end_true_01 at cg_pos
    hero "선배 묶였어 도와조"
    "그대로 둔 채 집에 돌아왔다"
    scene cg end_true_01 at slow_zoom
    hero "에에에에????"
    "【 회피엔딩 】"
    return

label ending_gate_promise:
    # 애매한 엔딩: 어디서 끝내든 교문 앞
    $ persistent.endings.add("gate")
    hide hero
    scene cg end_gate_01 with fade
    "우리는 교문 앞으로 돌아왔다."
    hero "아쉽다.. 그러니까 다음 밤에 또 같이 모험하자"
    me "그래요그래요"
    "【 다음에 또 】"
    return

label ending_cthulhu:
    $ persistent.endings.add("cthulhu")

    # 도서관 배경 + 히로인 (엔딩 다시 보기에서도 같은 장면으로 시작)
    scene bg library
    show hero think at hero_pos

    "마지막 불가사의의 열쇠, 표지 없는 수상한 책을 펼치는 순간 -"

    show hero surprise
    hero "에?? 엥?????"

    "선배의 등 뒤에서 무언가 촉수같은 것이 덮쳐온다."

    show hero surprise_c
    hero "도와줘 후배!!"

    menu:
        "손을 뻗어 구하려한다":
            show hero surprise_c
            hero "거부이! 고마..ㅇ"
            "구할 수 없었다"

        "그냥 구경한다":
            show hero think_c
            hero "야!! 잇자ㅅ.. "
            "거부이도 이건 좀.."

    "이건...."

    # 잠깐 암전 후 엔딩 일러스트
    hide hero
    scene black with Dissolve(0.8)
    pause 1.5
    scene cg end_cthulhu_01 with Dissolve(4)
    "..."
    "나라도 집에 돌아가는 편이 좋을 것 같다"
    "【 진짜 공포 】"
    return

label ending_all_clear:
    # 전부 해결 + 도서관 이외의 장소
    $ persistent.endings.add("clear")
    hide hero
    scene cg end_clear_01 with fade
    "7대불가사의를 모두 밝혀냈다! 우리는 뿌듯하게 학교를 나섰다."
    hero "다음엔 뭘 핑계로 후배를 부르지?"
    me "그냥 아무것도 안하고 불러도 상관없어요"
    hero "그래도 후배랑 같이 재밌게 놀고싶은걸"
    me "무리한 일을 안벌이고 같이 대화하는걸로 후배는 만족해요"
    "【 대성공 】"
    return

label event_gate_return:
    $ gate_returns += 1

    if gate_returns == 1:
        # 첫 번째 귀환
        show hero upset
        hero "혹시 선배랑 노는거 재미없어졌어?"

        menu:
            "실수실수~ 길을 잘못들었네":
                show hero sad
                hero "그런거지?"
                show hero talk
                hero "...그럼 다시 돌아가자!"

            "거부이 지쳐서 집에 가고싶어...":
                show hero think
                hero "아... 그랬구나."
                show hero sneer
                hero "그래도 안보내줄거지롱"
    elif gate_returns == 2:
        # 두 번째 귀환
        show hero angry
        hero "또 돌아왔어?! 진짜 선배랑 노는 거 싫은 거 맞지!"

        menu:
            "아니 이게 학교가 길이 어렵네":
                show hero shy
                hero "진자 머라는거야! 다시 돌아가자"

            "후배 집 갈래 보내줘 우우":
                show hero proud
                hero "오늘 밤을 후배를 재우지않을거야"

    else:
        # 세 번째 이후
        show hero sad
        hero "후배, 진짜로 선배가 미운거지"

        menu:
            "진짜 실수야! 빨리 돌아가자":
                show hero think
                hero "아... 뭐, 그래! 믿을게!"

            "솔직히 좀 집에 가고 싶어.":
                show hero sad
                hero "...그래도 끝까지 같이 있어 줘."

    return

# ===== 음악실 =====
label rumor_music:
        show hero think
        hero "음악실에는 이런 소문이 있어..."
        show hero upset
        hero "아무도 없는 밤에, 혼자 피아노가 울린대."
        show hero talk
        hero "그 소리를 들은 사람은 모두 바보가 됐다나"
        show hero normal
        menu:
            "선배도 들었어요?":
                show hero angry
                hero "잇자식이!! 조사나 해!"

            "헉 너무 무서워":
                show hero veryhappy
                hero "후배는 이미 바보니까 괜찮아"
        show hero normal
        return
# item조사 선행대화
label item_m1:
    show hero think
    hero "메트로놈? 아직도 켜져있네"
    me "완전 수상해 선배"
    show hero talk
    hero "수업이 끝나고도 종종 빌려쓰는 부가 있으니까말이지 흠~"
    show hero normal
    return

label item_m2:
    show hero think
    hero "그랜드 피아노라니.. 이런 비싼 악기를 용케 들였네"
    menu:
        "후배의 연주실력을 보여줄 차롄가?":
            show hero veryhappy
            hero "오오 어디 한번 들어볼까??"

        "선배 피아노 쳐줘요":
            show hero think
            hero "음~ 선배 피아노는 체르니 때 접었는데~"
    show hero talk
    hero "어라? 소리가 잘 안나는데?"
    show hero normal
    return

label item_m3:
    show hero think
    hero "악보 더미네. 후배는 클래식도 자주 들어?"
    menu:
        "후배는 거의 뭐 베토벤의 환생임":
            show hero veryhappy
            hero "그럼 안듣는다고 봐야하지않아..?"

        "후배는 여자목소리 안들리면 안들어":
            show hero surprise
            hero "헐랭"
    show hero normal
    return

label item_m4:
    show hero think
    hero "피아노 의자? 의자에 뭐가 있을까..?"
    menu:
        "후배가 조사를 위해 냄새를 맡아볼게":
            show hero surprise
            hero "후배야! 정신차려이..!! 많이 졸려?"

        "후배가 의자를 많이 부숴봐서 이쪽 업계에선 전문가야":
            show hero smile
            hero "후배가 그런 지식이 있을 줄은 몰랐네"
    show hero sneer
    me "의자에서 뭔가를 찾았어!"
    show hero surprise
    hero "진자냐!"   
    show hero normal
    return

label clues_piano:
    show hero think
    hero "망가진 피아노와 블루투스 스피커.."
    show hero talk
    hero "음악 선생님은 스피커를 틀고 연주하는 척을 했던거야!!!"
    me "그게 진짜면 선생님 너무 짜치는데."
    me "그리고 왜 그게 괴담의 해답이에요?"
    show hero proud
    hero "아무도 없는 곳에서 음악이 연주되는법..."
    hero "{size=+5}그거슨!!!{/size} 잘못 연결된 블루투스겠지 머~"
    show hero normal
    return

# ===== 2학년교실 =====
label rumor_class:
        show hero think
        hero "이 교실에 얽힌 소문을 들려주지..."
        show hero upset
        hero "여기 2분단 맨 뒷자리말이야"
        show hero talk
        hero "앉는 사람은 전부 성적이 떨어져서말이지\n계속 빈자리로 둔다나봐"
        show hero talk
        hero "그런데도 책상이 점점 더러워진대"
        show hero normal
        me "더러워지는건 모르겠고 성적이 떨어지는건 진짜 무섭네요"
        return
# item조사 선행대화
label item_c1:
    show hero think
    hero "사물함이라..괴담의 책상과 가까운 쪽을 조사해봐야겠지? \n그런데 다른사람걸 함부로 열어도 괜찮을까?"
    menu:
        "후배는 이런 짓을 할때 희열을 느껴":
            show hero sneer
            hero "선배 사물함에는 자물쇠를 걸어둬야겠어"

        "후배는 사실... 도둑이야!":
            show hero veryhappy
            hero "그래서 선배 마음도 훔쳐갔구만~!"
    show hero surprise
    hero "으엑 이게 뭐람"
    show hero normal
    return

label item_c2:
    show hero think
    hero "출석부네~ 선배는 반 애들 이름 외우기 힘들어서말이지"
    me "말이지?"
    show hero smile
    hero "선생님이 누구 불러오라고 하면 출석부 보고 찾아갔어"
    me "선배 뭔가 실망이에요"
    show hero normal
    return

label item_c3:
    show hero think
    hero "이 책상이지? 확실히 꽤 낡았네 그런데 수상한 점은 없는걸?"
    me "이쪽 모서리에 커터칼로 이름을 새겨뒀어"
    show hero surprise
    hero "헐 진짜네! 공용물건에다 왜 이런 짓을 하는거람"
    menu:
        "맞아 진짜 악질이지! 영구추방해버려야해":
            show hero think
            hero "어.. 나쁘긴한데.. 거기까진 좀 과할지도 "

        "후배도 선배이름 대빵 크게 새겨뒀어":
            show hero shy
            hero "마음은 고맙지만 그럼 선배까지 나쁜사람되잔아 잇자식"
    show hero talk
    hero "일단은 이 이름.. 찾아봐야겠어"
    show hero normal
    return

label item_c4:
    show hero shy
    hero "으앗!! 왜 갑자기 엎드려서 바닥을 보는거야! 놀랐잖아"
    menu:
        "선배의 팬티가 보고싶었어":
            show hero shy
            hero "변태야!! 얼른 일어나! 우.."

        "이쪽 바닥 뭔가 이상해서":
            show hero normal
            hero "앗! 그렇구나 오해해서 미안해.."
    show hero normal
    me "아무튼! 이쪽의 바닥이 좀 패여있네요~"
    return

label item_c5:
    show hero shy
    hero "쓰레기통? 후배 용케 그런 곳에 손을 집어넣는구나"
    menu:
        "쓰레기통에 자주 들어가봤거든":
            show hero shy
            hero "에? 어쩌다가??"

        "선배를 위해서라면 뭐든 할 수 있어":
            show hero veryhappy
            hero "우히히 감동이얌"
    show hero normal
    me "딱히 눈에 띄는건 없네. 대부분 구겨진 시험지들이야"
    return

label clues_desk:
    show hero think
    hero "이름이 새겨진 책상. 그리고 그 이름의 주인을 알았어"
    show hero angry
    hero "책상을 막 다루고서 그나마 깨끗한 안쓰는 자리의 책상과 바꾸고 있는거야"
    me "그러게요 이쪽 자리는 책상이 꽤 깨끗해요."
    me "자리도 그냥 좀 불편해서 안쓰는 것 같구요"
    show hero normal
    hero "성적은 핑계같어 그치?"
    return

# ===== 수영장 =====
label rumor_pool:
        show hero think
        hero "여기 수영장의 소문이 제일 무서웠어"
        show hero think
        hero "밤 늦게까지 수영연습을 하던 학생이 있었다는데"
        show hero angry
        hero "자신이 도착하기전에 먼저 도착해 벽을 짚는 손을 봤대"
        show hero normal
        hero "그런데 주변엔 아무도 없었다더라"
        show hero normal
        me "밤늦게까지 혼자 수영했다면 귀신도 무서웠겠는데요"
        return

# 선행대화
label item_p1:
    show hero think
    hero "사다리! 선배는 이거 좀 무서워"
    menu:
        "선배 그런 루저 허접 겁쟁이에요?":
            show hero angry
            hero "아냐! 몇년전부터 사다리가 좀 망가져있다구!!"

        "에고 선배 무서워써요~~?":
            show hero upset
            hero "망가져있어서 괜히 다칠까봐 무서운거야."
    show hero talk
    hero "아무튼 소문과는 별로 관련없는 것 같아"
    show hero normal
    return

label item_p2:
    show hero talk
    hero "펜스네? 역시 우리 학교 수영장 펜스 좀 낮지않아?"
    menu:
        "후배는 그래서 이 학교에 진학했어요":
            show hero sneer
            hero "그게 진짜면 거부이한테 조금 질릴지도..."

        "선배키로는 어차피 반대쪽이 안보이죠?":
            show hero shy
            hero "갑자기 시비야! 잇자식!!"
    show hero talk
    hero "암튼! 낮아서 그런가? 구석쪽에 수건이라던지 수영복같은게 널려있네"
    me "주인 여자임?"
    show hero normal
    return

label item_p3:
    show hero talk
    hero "수영장레인? 조사해보고싶지만 여벌옷도 없구"
    menu:
        "진자냐! 빨리 들어가잇":
            show hero shy
            hero "야! 밀지마!! 선배 수영 못한단말이야아"

        "후배도 젖기시러용":
            show hero normal
            hero "역시 그렇겠지?"
    show hero smile
    hero "여기서 대충 보면 돼. 선배 눈시력 짱 조아"
    show hero angry
    hero "딱히 뭐가 보이진않네"
    show hero normal
    return

label item_p4:
    show hero shy
    hero "탈의실 이러네!!!!!"
    menu:
        "선배는 무서울테니 거부이가 들어가껨":
            show hero angry
            hero "보내줄 것 같아! 여기 딱 붙어있어 이 변태짜식"

        "후배 인생일대소원 제발제발제발제발":
            show hero shy
            hero "되겠냐!!!"
    show hero upset
    hero "여기 들어오기전에 선배가 확인해봤어"
    show hero sneer
    hero "뭐 없었어~ 이런걸 원하다니 정말! 초딩이냐!"
    show hero normal
    return

label clues_swim:
    show hero think
    hero "수영장의 도착지점이라면 이쪽이였겠지?"
    show hero talk
    hero "밤이라 조명을 켰겠지만 물속에선 분간이 힘들었을거야"
    me "그래서 그냥 공포가 만들어낸 가짜기억아닐까싶어요"
    show hero sneer
    hero "내 생각엔 이 수건이 의심스러워!"
    me "물에 비친 수건을 손으로 본거라구요? 뭔가 짜치지만 뭐..."
    return

# ===== 여자화장실 =====
label rumor_toilet:
        show hero think
        hero "여긴 별로 안오고싶었는데.. 우"
        show hero upset
        hero "별건 아니고 마지막칸에서 간혹 여자울음소리가 들린대"
        show hero talk
        hero "별거 아니지?"
        show hero normal
        menu:
            "여성분이 울고있다는데 갈!!!!!":
                show hero sad
                hero "으익 거뿌이 머야"

            "예쁨?":
                show hero angry
                hero "그걸 내가 어떻게 알아! 참나"
        show hero normal
        return
# item조사 선행대화
label item_t1:
    show hero smile
    hero "화장실의 큰 거울~ 밤에 보면 진짜 무섭지~!"
    menu:
        "후배는 그런걸로 겁 안먹음":
            show hero angry
            hero "이럴땐 그냥 공감해! 잇자식"

        "거뿌이 지려써 따까조":
            show hero surprise
            hero "진짜냐????"
            show hero upset
            hero "아니네.. 다행이다 이런 장난 치지마아~"
    show hero talk
    hero "암튼 계속 바라봐도 딱히 달라지는건 없네?"
    show hero normal
    return

label item_t2:
    show hero think
    hero "음 역시 칸 안쪽도 봐야겠지?"
    menu:
        "후배가 앞장서겠소":
            show hero surprise
            hero "이럴때만? 헐랭~"

        "후배 여자화장실의 지리를 잘 알아 전문가임":
            show hero normal
            hero "엥? 갑작이?"
    show hero happy
    hero "뭐.. 그래도 먼저 봐줘서 고마워 조금 무서웠거든..ㅎㅎ"
    show hero normal
    hero "뭔가 있었어?"
    me "딱히 없었어. \n그런데 화장실을 잘못 만들었나? 창문이 칸안쪽까지 들어와있더라"
    return

label item_t3:
    show hero think
    hero "어디어디 세면대를 봐볼까?"
    show hero talk
    hero "깨끗하긴한데 비누가 다 떨어져있네?"
    me "수압도 괜찮네 따듯한 물도 잘 나오고"
    show hero normal
    return

label item_t4:
    show hero think
    hero "화장실 청소당번 해봤어?"
    menu:
        "후배는 안해봤어":
            show hero normal
            hero "보통은 벌점때문에 청소하니까~ 후배라면 그렇겠지?"

        "해봤어 우우":
            show hero surprise
            hero "에? 착한 후배가 어쩌다가?"
            me "후배보다 강한 애가 시켰어"
            show hero think
            hero "아이고 저런"
    show hero talk
    hero "빨리 나가자! 물건들도 잘 정리되어있고 이상한건 없네"
    show hero normal
    return

label clues_window:
    show hero talk
    hero "오! 그렇네!"
    show hero proud
    hero "후후후 이 소문은 그저 바람소리였던 것이다"
    hero "쉽다 쉬워!"
    return

# ===== 중앙계단 =====
label rumor_stairs:
        show hero proud
        hero "흠흠 중앙계단은 후배에겐 이른 곳이지"
        show hero sneer
        hero "중앙계단은 선배들의 특권이라고~"
        me "틀딱"
        show hero angry
        hero "얌마!"
        show hero talk
        hero "아무튼 중앙계단은 흔한 이야기야"
        hero "올라갈 때마다 계단수가 달라진다던데?"
        show hero normal
        return
# item조사 선행대화
label item_s1:
    show hero normal
    hero "소화기네? 후배 쓸 줄 알아?"
    menu:
        "후배는 뭐든 할 줄 알아!":
            show hero sneer
            hero "그렇게 말하니까 뭔가 못할 확률이 더 높을 것 같네"

        "응애":
            show hero happy
            hero "갑자기 모야~"
            show hero smile
            hero "후후 선배가 지켜주껨"
    show hero normal
    hero "잘 보니 유효기간이 한참 지났네 음~"
    return

label item_s2:
    show hero talk
    hero "역시 바로 해보는게 빠르지!"
    show hero normal
    hero "하나.. 둘.. 셋... 넷.."
    show hero talk
    hero "후배는 몇칸이였어?"
    menu:
        "열세칸!":
            show hero smile
            hero "선배는 열두칸이였오"

        "열두칸?":
            show hero smile
            hero "선배는 열세칸~!"
    me "그럼 소문이 진짜였던건가!!"
    show hero normal
    return

label item_s3:
    show hero talk
    hero "비상구 표지판이네! \n우리 학교 다니다보면 이거 가려진 곳도 꽤 있다?"
    show hero normal
    hero "뭔가 안전불감증이 심한 것 같아"
    menu:
        "후배는 불감증 없어":
            show hero think
            hero "에~~ 음 신경을 잘 쓴다는건 좋은거야!"

        "불감증이 뭐야?":
            show hero shy
            hero "그런거 선배한테 물어보지마~! 변태!"
    show hero talk
    hero "여긴 관리도 잘 되어있고 문제 없네!"
    show hero normal
    return

label item_s4:
    show hero talk
    hero "후배? 거울만 뚫어져라 쳐다보고있네?? 모해~?"
    menu:
        "거울이랑 가위바위보":
            show hero normal
            hero "어.. 응 그렇구나"

        "거울아거울아~ 누가 제일 예쁘니?":
            show hero shy
            hero "아잉 당연히 선배겠지?"
            me "누르렁하고 짜치는 이름을 가지고 있는 토끼선배는 아닙니다~"
            show hero angry
            hero "야아!!!!!"
    show hero upset
    hero "됐어 이제 거울 그만. 문제없는건 확인했지?"
    show hero normal
    return

label clues_stair:
    show hero sneer
    hero "우후후 역시 평범한 소문이네~"
    show hero proud
    hero "어디를 계단의 첫칸으로 생각하는가가 중요한거지!"
    show hero smile
    hero "후배랑 선배는 다르게 생각하나봐{size=-14}...그건 아쉽네{/size}"
    show hero normal
    return

# ===== 도서관 =====
label rumor_library:
        show hero talk
        hero "도서관! 선배는 학교에서 도서관이 제일 좋아"
        show hero think
        hero "그런 도서관에 이상한 소문이 도는건 사양이야"
        hero "아닌가? 어쩌면 사람이 안와서 더 좋을지도"
        me "후배는 선배랑 단둘이 있는게 좋아요"
        show hero smile
        hero "히히 도서관의 소문을 말해줄게"
        hero "도서관의 어딘가에 신기한 책이 있대"
        show hero talk
        hero "아무도 빌리지않는데 대출카드에는 이름이 늘어난다고해"
        hero "한번 확인해보자구!"
        show hero normal
        return

# item조사 선행대화
label item_l1:
    show hero normal
    hero "대출 카운터네. 요즘은 전산처리하니까 역시 대출카드용 도장은 없어"
    menu:
        "그런데 대출카드가 뭐야?":
            show hero shy
            hero "으에? 모르는거야?"
            show hero talk
            hero "옛날엔 아날로그 카드로 책을 빌렸었어"
            hero "날짜표 구경하는 것도 꽤 흥미롭다구?"

        "그런걸 아는걸 보니 나이가 많아보이네":
            show hero angry
            hero "잇자식 시비걸지마"
    show hero normal
    hero "책상을 보니 사서선생님도 모를거야.\n역시 제대로 책을 찾아보는게 좋겠어"
    return

label item_l2:
    show hero talk
    hero "신문 열람대야. 뭔가 정리가 잘 안돼있네"
    me "요즘 누가 신문을 읽어"
    me "인터넷에 보면 다 나와!"
    show hero normal
    hero "너무 인터넷 많이 하진마~ 모두가 정답만 말하진않는다구"
    return

label item_l3:
    show hero talk
    hero "분류표네. 후배는 보통 어떤 책을 읽어?"
    menu:
        "후배는 책 안읽어":
            show hero normal
            hero "바쁘면 그럴 수 있지"

        "후배는 W@@? 사@@와 성":
            show hero surprise
            hero "아직도 그걸 읽는거야?"
    show hero normal
    hero "음~ 보통 향토자료 쪽이 정말 읽는 사람이 적은 것 같아"
    return

label item_l4:
    show hero talk
    hero "책장! 아무래도 책은 사람들이 잘 안보는 곳에 숨겨뒀을 것 같지?"
    show hero angry
    hero "흠~ 어디에어디에 이쓰까나~"
    show hero veryhappy
    hero "찾았당!"
    return

label clues_book:
    show hero think
    hero "음~ 뭔가 낡았지만 비싸보이는 책이네"
    show hero talk
    hero "읽어 보니 그냥 옛날 학생이 쓴 괴담 소설 같은데?"
    me "소문이 부풀려진 거였네요."
    show hero proud
    hero "그러게 그리고 독서카드부분도 엉성하게 수기로 흉내낸 것 같아"
    me "만든 사람은 괴담을 정말 좋아하나봐요"
    show hero normal
    return

# ===== 보건실 =====
label rumor_nurse:
        show hero talk
        hero "보건실의 소문을 알려주겠노라"
        show hero think
        hero "해질녘, 운동 중에 다리를 다쳐서 보건실을 찾아간 학생이 있었대.."
        show hero angry
        hero "보건선생님이 없어서 돌아가려던 그때.."
        hero "분명 아무도 없어야 할 방과후의 보건실에서...."
        show hero surprise
        hero "고통스러워하는 여학생의 목소리를 들었대"
        show hero think
        hero "소문에는 옛날에 이 보건실에서 죽은 여학생이 있다나?"
        show hero normal
        hero "무섭지? 얼른 불가사의를 해결해보자"
        return

# item조사 선행대화
label item_n1:
    show hero smile
    hero "체온계야. 후배의 체온을 한번 재볼까나?"
    menu:
        "부끄럽지만 잘 부탁해 선배":
            show hero shy
            hero "평범하게 이마에 대고 재는거야!"


        "선샌니 목이 칼칼하고 어지러워요":
            show hero veryhappy
            hero "히히 우리 환자분 검사해보께용~"
    show hero normal
    hero "체온은 평범하네! 건강한니까 좋네!"
    return

label item_n2:
    show hero smile
    hero "침대야. 뭔가 장치가 되어있는걸까?"
    menu:
        "침대시트를 조사한다":
            show hero shy
            hero "에취~ 침대 밑에는 아무것도 없었어 먼지는 좀 많네.."
            me "침대시트는 깨끗해요 자주 갈아주나봐요"


        "침대 밑을 조사한다":
            show hero talk
            hero "어때 그 밑에선 무언가 보여? 여긴 평범하네"
            me "선배의 다리가 보여요 으흐흐"
            show hero angry
            hero "진지하게 조사해 잇자식!"
    show hero normal
    hero "이상하네 아무것도 없어"
    return

label item_n3:
    show hero think
    hero "약장이야. 열쇠로 잠겨있어."
    menu:
        "후배가 따볼게":
            show hero smile
            hero "에이 거부이 장난치지마러~"
            me "장난아닌데"


        "부숴볼까?":
            show hero surprise
            hero "우아아 멈춰멈춰!!!"
            me "농담농담~"
            show hero angry
            hero "놀리지마! 정말루!"
    show hero normal
    hero "대충 봤을땐 뭔가 특별한 장치는 없는 것 같아"
    return

label item_n4:
    show hero think
    hero "우우.. 체중계네. 굳이 조사할 필욘 없지않을까?"
    menu:
        "선배가 올라가봐":
            show hero shy
            hero "헐 시러시러이 하지마러"


        "선배로 확인해보자":
            show hero shy
            hero "아아 하지마하지마"

    me "헉"
    show hero sad
    hero "체중계는 망가진 것 같아"
    me "멀쩡한 것 같은데"
    show hero angry
    hero "망가졌다구!!!"
    show hero normal
    return

label clues_bed:
    show hero think
    hero "음~ 역시"
    me "딱 알았네 그거네 그거"
    show hero sneer
    hero "역시 그거지?"
    show hero shy
    hero "요즘애들은 정말이지...!"
    show hero normal
    return

# ===== 뒤뜰 =====
label rumor_backyard:
        show hero think
        hero "음 뒤뜰... 뭔가 위험해보이는 소문이였어"
        show hero think
        hero "수상한 사람이 뒤뜰에 침입해왔다는 소문이 있더라고."
        hero "뭔가 범죄랑 관련있을 것 같기두하고.."
        me "그건 우리가 조사하는게 아니라 경찰에 맡겨야죠 선배 제정신이에요?"
        show hero smile
        hero "별거아닐지두 몰라..!"
        hero "옆에 후배도 있으니까 괜찮지않을까나..?"
        show hero talk
        hero "일단 한번 조사해보자!"
        show hero normal
        return

# item조사 선행대화
label item_b1:
    show hero think
    hero "벤치네. 사람이 잘 안오는 곳이라 그런지 관리가 잘 안되어있어"
    menu:
        "잠깐 쉬었다가요":
            show hero veryhappy
            hero "그러까나~"
            hero "여기 같이 앉아있으니까 기분조아"

        "부숴서 땔감으로 쓸까요?":
            show hero surprise
            hero "왓??? 그게 무슨소리니 거뿌이뿌이야"
    show hero talk
    hero "의자에는 낯선사람의 흔적같은건 보이지않아."
    show hero normal
    return

label item_b2:
    show hero sneer
    hero "이건 별로 수상해보이진않는걸..?"
    menu:
        "완전 수상해요":
            show hero sneer
            hero "굳이 가까이서 봐야할까나...?"
            hero "..."
            hero "...."
            show hero shy
            hero "사실 선배가 팠어"

        "침입자가 숨어든 땅굴아닐까요?":
            show hero surprise
            hero "어.. 그러면 가까이 가는건 위험하지않을까..?"
            hero "..."
            hero "...."
            show hero shy
            hero "사실 선배가 팠어"       
    show hero shy
    me "흠.. 안보일때마다 여기서 굴파고 있던거에요?"
    show hero normal
    return

label item_b3:
    show hero talk
    hero "음? 평범한 화단인데??"
    menu:
        "뭔가 난장판이에요":
            show hero think
            hero "음.. 그런가?"
            me "식물들이 다 쥐어뜯겨있어요"
            me "못된 침입자녀석! 악독하게 식물을 괴롭히다니"
            hero "...."
            show hero shy
            hero "야! 선배가 한 짓인거 알고 그렇게 놀리는거지!"

        "식물들이 상태가 이상해요":
            show hero think
            hero "흠.. 그래? 후배 의외로 식물에 박식하구나"
            hero "..."
            hero "후배?"
            me "선배가 한 짓이죠?"
            show hero shy
            hero "아무도 안오는 곳이라 괜찮을줄 알았어!!!"       
    show hero shy
    me "선배, 그냥 급식 먹어요"
    show hero normal
    return

label clues_bunny:
    show hero sneer
    me "선배도 알고있었죠"
    hero "몰랐을지도~??"
    me "선배는 벽보고 반성하세요"
    show hero sad
    hero "잉잉 너무해 선배 나쁘다고하고 너무해"
    show hero normal
    return